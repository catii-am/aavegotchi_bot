# Resource Override

## ~~ This extension is now in maintenance mode!! ~~

See what this means here: [maintenance_notice.md](maintenance_notice.md).

Resource Override is an extension to help you gain full control of any website by redirecting traffic, replacing, editing, or inserting new content.

[Get the chrome extension here](https://chrome.google.com/webstore/detail/resource-override/pkoacgokdfckfpndoffpifphamojphii).

### Now on firefox!
[Get the FireFox extension here](https://addons.mozilla.org/en-US/firefox/addon/resourceoverride/)
