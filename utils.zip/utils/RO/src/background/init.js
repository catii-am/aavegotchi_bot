{
    window.bgapp = {};
    window.browser = window.browser ? window.browser : window.chrome;
}
